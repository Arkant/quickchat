(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[2],{

/***/ 1:
/***/ (function(module, exports) {

/* (ignored) */

/***/ }),

/***/ "2e05":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_1_id_39a159fc_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("62dc");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_1_id_39a159fc_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_1_id_39a159fc_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Chat_vue_vue_type_style_index_1_id_39a159fc_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "62dc":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "ab55":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@quasar/app/lib/webpack/loader.auto-import.js?kebab!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/Chat.vue?vue&type=template&id=39a159fc&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('q-page',{},[_c('div',{staticStyle:{"padding-bottom":"100px"}},_vm._l((_vm.messages),function(message,index){return _c('q-chat-message',{key:index,attrs:{"sent":message.username === _vm.username ? true : false,"name":("<b>" + (message.username) + "</b>"),"stamp":message.datetime.split(/[T Z .]/)[1] || message.datetime,"text":[message.message]}})}),1),_c('div',{staticClass:"flex fixed-bottom"},[_c('q-input',{staticClass:"input",attrs:{"fixed-bottom":"","type":"textarea","label":"Type in your message","rows":"3"},on:{"keyup":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.send($event)}},model:{value:(_vm.message),callback:function ($$v) {_vm.message=$$v},expression:"message"}})],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/Chat.vue?vue&type=template&id=39a159fc&scoped=true&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es7.object.get-own-property-descriptors.js
var es7_object_get_own_property_descriptors = __webpack_require__("8e6e");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es6.symbol.js
var es6_symbol = __webpack_require__("8a81");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom.iterable.js
var web_dom_iterable = __webpack_require__("ac6a");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es6.array.iterator.js
var es6_array_iterator = __webpack_require__("cadf");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es6.object.to-string.js
var es6_object_to_string = __webpack_require__("06db");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es6.object.keys.js
var es6_object_keys = __webpack_require__("456d");

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/toConsumableArray.js
var toConsumableArray = __webpack_require__("4db1");
var toConsumableArray_default = /*#__PURE__*/__webpack_require__.n(toConsumableArray);

// EXTERNAL MODULE: ./node_modules/@babel/runtime-corejs2/helpers/defineProperty.js
var defineProperty = __webpack_require__("c47a");
var defineProperty_default = /*#__PURE__*/__webpack_require__.n(defineProperty);

// EXTERNAL MODULE: C:/Users/Rostyslav/Desktop/quickchat/node_modules/socket.io-client/lib/index.js
var lib = __webpack_require__("30ca");
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);

// EXTERNAL MODULE: ./node_modules/vuex/dist/vuex.esm.js
var vuex_esm = __webpack_require__("2f62");

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--1-0!./node_modules/@quasar/app/lib/webpack/loader.auto-import.js?kebab!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/Chat.vue?vue&type=script&lang=js&









function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { defineProperty_default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ var Chatvue_type_script_lang_js_ = ({
  name: 'Chat',
  data: function data() {
    return {
      admin: '',
      message: '',
      messages: [],
      socket: lib_default()('https://fast-peak-37701.herokuapp.com')
    };
  },
  methods: {
    send: function send(e) {
      if (this.message.trim().length > 0) {
        e.preventDefault();
        var msg = {
          idUser: this.idUser,
          username: this.username,
          message: this.message.trim(),
          datetime: new Date().toLocaleTimeString()
        };
        this.socket.emit('send_message', msg);
        this.message = '';
      }
    }
  },
  computed: _objectSpread({}, Object(vuex_esm["b" /* mapGetters */])(['username', 'idUser'])),
  created: function created() {
    var _this = this;

    this.$store.dispatch('GET_MESSAGES').then(function (result) {
      _this.messages = result;
    }).then(function (res) {
      return res;
    }).catch(function (err) {
      console.err(err);

      _this.$q.notify({
        color: 'red',
        textColor: 'white',
        icon: 'report_problem',
        message: 'Could not load DB messages',
        position: 'top-right',
        timeout: Math.random() * 5000 + 3000
      });
    });
  },
  mounted: function mounted() {
    var _this2 = this;

    this.socket.on('send_message', function (data) {
      _this2.messages = [].concat(toConsumableArray_default()(_this2.messages), [data]);
    });
    this.socket.on('connect', function () {});
    this.socket.on('message', function (data) {
      _this2.messages = [].concat(toConsumableArray_default()(_this2.messages), [data]);
    });
    this.socket.on('clear all messages', function () {
      _this2.messages = [];
    });
  },
  beforeDestroy: function beforeDestroy() {
    this.messages = [];
  }
});
// CONCATENATED MODULE: ./src/pages/Chat.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Chatvue_type_script_lang_js_ = (Chatvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/pages/Chat.vue?vue&type=style&index=1&id=39a159fc&scoped=true&lang=css&
var Chatvue_type_style_index_1_id_39a159fc_scoped_true_lang_css_ = __webpack_require__("2e05");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__("eebe");
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);

// EXTERNAL MODULE: ./node_modules/quasar/src/components/page/QPage.js
var QPage = __webpack_require__("9989");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/chat/QChatMessage.js
var QChatMessage = __webpack_require__("8169");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/input/QInput.js + 4 modules
var QInput = __webpack_require__("27f9");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/field/QField.js + 3 modules
var QField = __webpack_require__("8572");

// CONCATENATED MODULE: ./src/pages/Chat.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Chatvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "39a159fc",
  null
  
)

/* harmony default export */ var Chat = __webpack_exports__["default"] = (component.exports);





runtime_auto_import_default()(component, 'components', {QPage: QPage["a" /* default */],QChatMessage: QChatMessage["a" /* default */],QInput: QInput["a" /* default */],QField: QField["a" /* default */]})


/***/ })

}]);
//# sourceMappingURL=2.js.map