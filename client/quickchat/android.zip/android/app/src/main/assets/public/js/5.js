(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[5],{

/***/ "8fb2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/@quasar/app/lib/webpack/loader.auto-import.js?kebab!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/Sign-up.vue?vue&type=template&id=ae49d8ce&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('q-page',{staticClass:"row justify-center items-center"},[_c('div',{staticClass:"column"},[_c('div',{staticClass:"row"},[_c('q-card',{staticClass:"q-pa-lg shadow-1",attrs:{"square":"","bordered":""}},[_c('q-card-section',[_c('q-form',{staticClass:"q-gutter-md"},[_c('q-input',{attrs:{"square":"","filled":"","clearable":"","type":"name","label":"Username"},model:{value:(_vm.username),callback:function ($$v) {_vm.username=$$v},expression:"username"}}),_c('q-input',{attrs:{"square":"","filled":"","clearable":"","type":"password","label":"Password"},model:{value:(_vm.password),callback:function ($$v) {_vm.password=$$v},expression:"password"}}),_c('q-input',{attrs:{"square":"","filled":"","clearable":"","type":"password","label":"Confirm password"},model:{value:(_vm.confirmPassword),callback:function ($$v) {_vm.confirmPassword=$$v},expression:"confirmPassword"}})],1)],1),_c('q-card-actions',{staticClass:"q-px-md"},[_c('q-btn',{staticClass:"full-width",attrs:{"unelevated":"","disabled":!_vm.isBtnDisabled,"color":"blue","size":"lg","label":"Sign Up"},on:{"click":_vm.signUp}})],1)],1)],1)])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/Sign-up.vue?vue&type=template&id=ae49d8ce&

// CONCATENATED MODULE: ./node_modules/babel-loader/lib??ref--1-0!./node_modules/@quasar/app/lib/webpack/loader.auto-import.js?kebab!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/Sign-up.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ var Sign_upvue_type_script_lang_js_ = ({
  name: 'SignUp',
  data: function data() {
    return {
      username: '',
      password: '',
      confirmPassword: ''
    };
  },
  computed: {
    isBtnDisabled: function isBtnDisabled() {
      return this.password === this.confirmPassword && this.password !== '' && this.confirmPassword !== '' && this.username !== '';
    }
  },
  methods: {
    signUp: function signUp() {
      var _this = this;

      this.$store.dispatch('SIGN_UP_USER', {
        username: this.username,
        password: this.password
      }).then(function (result) {
        _this.$router.push('/chat');
      }).catch(function (res) {
        _this.showNotif('top-right', 'Could not sign-up. Try again later.');

        console.error('Could not sign-up. Try again later.');
      });
    },
    showNotif: function showNotif(position, message) {
      this.$q.notify({
        color: 'red',
        textColor: 'white',
        icon: 'report_problem',
        message: message,
        position: position,
        timeout: Math.random() * 5000 + 3000
      });
    }
  }
});
// CONCATENATED MODULE: ./src/pages/Sign-up.vue?vue&type=script&lang=js&
 /* harmony default export */ var pages_Sign_upvue_type_script_lang_js_ = (Sign_upvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./src/pages/Sign-up.vue?vue&type=style&index=0&lang=css&
var Sign_upvue_type_style_index_0_lang_css_ = __webpack_require__("d5df");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./node_modules/@quasar/app/lib/webpack/runtime.auto-import.js
var runtime_auto_import = __webpack_require__("eebe");
var runtime_auto_import_default = /*#__PURE__*/__webpack_require__.n(runtime_auto_import);

// EXTERNAL MODULE: ./node_modules/quasar/src/components/page/QPage.js
var QPage = __webpack_require__("9989");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/card/QCard.js
var QCard = __webpack_require__("f09f");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/card/QCardSection.js
var QCardSection = __webpack_require__("a370");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/form/QForm.js
var QForm = __webpack_require__("0378");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/input/QInput.js + 4 modules
var QInput = __webpack_require__("27f9");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/card/QCardActions.js
var QCardActions = __webpack_require__("4b7e");

// EXTERNAL MODULE: ./node_modules/quasar/src/components/btn/QBtn.js + 3 modules
var QBtn = __webpack_require__("9c40");

// CONCATENATED MODULE: ./src/pages/Sign-up.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  pages_Sign_upvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var Sign_up = __webpack_exports__["default"] = (component.exports);








runtime_auto_import_default()(component, 'components', {QPage: QPage["a" /* default */],QCard: QCard["a" /* default */],QCardSection: QCardSection["a" /* default */],QForm: QForm["a" /* default */],QInput: QInput["a" /* default */],QCardActions: QCardActions["a" /* default */],QBtn: QBtn["a" /* default */]})


/***/ }),

/***/ "d5df":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Sign_up_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("e644");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Sign_up_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Sign_up_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */
 /* unused harmony default export */ var _unused_webpack_default_export = (_node_modules_mini_css_extract_plugin_dist_loader_js_ref_5_oneOf_2_0_node_modules_css_loader_dist_cjs_js_ref_5_oneOf_2_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_5_oneOf_2_2_node_modules_quasar_app_lib_webpack_loader_auto_import_js_kebab_node_modules_vue_loader_lib_index_js_vue_loader_options_Sign_up_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "e644":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

}]);
//# sourceMappingURL=5.js.map